let x = 4
let y = 3
let z = 2
let w = Math.pow((x+y*z)/(x*y),z)
console.log(w)
